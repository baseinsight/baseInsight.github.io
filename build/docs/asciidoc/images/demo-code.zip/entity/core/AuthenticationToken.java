package com.bmzymtr.business.entity.core;

import com.bmzymtr.business.entity.core.Embedded.AuditingData;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.util.Date;
@Comment("认证token表")
@DynamicUpdate
@Table(name = "authentication_token")
@Entity
public class AuthenticationToken {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private Long id;
    @NotNull(message = "tokenValue不允许为空")
    @Comment("tokenValue")
    @Column(name = "token_value",nullable = false)
    String tokenValue;
    @NotNull(message = "用户名称不允许为空")
    @Comment("用户名称")
    @Column(name = "username",nullable = false)
    String username;
    @Comment("交互次数")
    @Column(name = "access_count",nullable = false)
    Integer accessCount=0;
    @Embedded
    private AuditingData auditingData = new AuditingData();

    public AuditingData getAuditingData() {
        return auditingData;
    }

    public void setAuditingData(AuditingData auditingData) {
        this.auditingData = auditingData;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTokenValue() {
        return tokenValue;
    }

    public void setTokenValue(String tokenValue) {
        this.tokenValue = tokenValue;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getAccessCount() {
        return accessCount;
    }

    public void setAccessCount(Integer accessCount) {
        this.accessCount = accessCount;
    }
}
