package com.bmzymtr.business.entity.core;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.DynamicUpdate;

@Comment("系统权限表")
@DynamicUpdate
@Table(name = "privilege")
@Entity
public class Privilege {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private Long id;
    @NotNull(message = "权限名称不允许为空")
    @Comment("权限名称")
    @Column(name = "name", length = 100, nullable = false, unique = true)
    private String name;
    @Comment("权限描述")
    @Column(name = "description", length = 100)
    private String description;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}