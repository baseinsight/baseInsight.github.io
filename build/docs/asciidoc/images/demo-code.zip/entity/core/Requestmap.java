package com.bmzymtr.business.entity.core;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.Comment;
import org.springframework.http.HttpMethod;

@Comment("访问控制表")
@Table(name = "requestmap")
@Entity
public class Requestmap {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private Long id;
    @Version
    @Column(name = "version")
    private int version;
    @NotNull(message = "名称不允许为空")
    @Comment("名称")
    @Column(name = "name",nullable = false, unique = true)
    private String name;
    @NotNull(message = "url不允许为空")
    @Comment("访问地址")
    @Column(name = "url", nullable = false, unique = true)
    private String url;
    @Comment("访问方法")
    @Column(name = "http_method")
    private HttpMethod httpMethod;
    @NotNull(message = "配置属性不允许为空")
    @Comment("配置属性")
    @Column(name = "config_attribute")
    private String configAttribute;

    public String getConfigAttribute() {
        return configAttribute;
    }

    public void setConfigAttribute(String configAttribute) {
        this.configAttribute = configAttribute;
    }

    public HttpMethod getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(HttpMethod httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}