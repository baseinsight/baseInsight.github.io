package com.bmzymtr.business.entity.core;

import com.fasterxml.jackson.annotation.JsonFormat;
import info.baseinsight.core.SpringUtils;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.sql.Timestamp;


/**
 * 系统基本用户类
 */
@Comment("系统用户表")
@Table(name = "base_user", indexes = {
        @Index(name = "idx_baseuser_username", columnList = "username")
})
@Entity
@GenericGenerator(name="jpa-uuid",strategy = "uuid") //uuid,guid,hilo,assigned,identity,select,sequence,seqhilo,increment,foreign,uuid.hex,sequence-identity
@EntityListeners(AuditingEntityListener.class)
public class BaseUser  implements org.camunda.bpm.engine.identity.User{
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(generator = "jpa-uuid")
    private String id;
    @Version
    @Column(name = "version")
    private int version;
    @NotNull(message = "租户信息不允许为空")
    @Comment("隶属租户")
    @ManyToOne
    @JoinColumn(name = "tenant_id")
    private Tenant tenant;
    @NotBlank(message = "用户名不允许为空")
    @Column(name = "username", nullable = false, unique = true)
    @Comment("用户名")
    private String username;
    @Email
    @NotBlank(message = "email不允许为空")
    @Column(name = "email", nullable = false, unique = true)
    @Comment("email")
    private String email;
    @NotBlank(message = "firstName不允许为空")
    @Comment("firstName")
    @Column(name = "first_name", nullable = false)
    private String firstName;
    @NotBlank(message = "lastName不允许为空")
    @Comment("lastName")
    @Column(name = "last_name", nullable = false)
    private String lastName;
    @NotBlank(message = "密码不允许为空")
    @Comment("密码")
    @Column(name = "password")
    private String password;
    @Comment("账户是否启用")
    @Column(name = "enabled")
    private boolean enabled=true;
    @Comment("账户是否过期")
    @Column(name = "account_expired")
    private boolean accountExpired;
    @Comment("账户是否锁定")
    @Column(name = "account_locked")
    private boolean accountLocked;
    @Comment("密码是否过期")
    @Column(name = "password_expired")
    private boolean passwordExpired;
    @Comment("创建时间")
    @CreatedDate
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "created_date",nullable = false)
    private Timestamp createdDate;
    @Comment("修改时间")
    @LastModifiedDate
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "last_modified_date",nullable = false)
    private Timestamp lastModifiedDate;

    @Transient
    private String passwordTransient;

    public String getPasswordTransient() {
        return passwordTransient;
    }

    public void setPasswordTransient(String passwordTransient) {
        this.passwordTransient = passwordTransient;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public Timestamp getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Timestamp lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
    public boolean getPasswordExpired() {
        return passwordExpired;
    }

    public void setPasswordExpired(boolean passwordExpired) {
        this.passwordExpired = passwordExpired;
    }

    public boolean getAccountLocked() {
        return accountLocked;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isAccountExpired() {
        return accountExpired;
    }

    public boolean isAccountLocked() {
        return accountLocked;
    }

    public boolean isPasswordExpired() {
        return passwordExpired;
    }

    public void setAccountLocked(boolean accountLocked) {
        this.accountLocked = accountLocked;
    }

    public boolean getAccountExpired() {
        return accountExpired;
    }

    public void setAccountExpired(boolean accountExpired) {
        this.accountExpired = accountExpired;
    }

    public boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
        if(password!=null && this.passwordTransient==null){
            this.passwordTransient =password;
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return username;
    }

    @jakarta.persistence.PrePersist
    public void prePersist() {
        encodePassword();
    }

    @jakarta.persistence.PreUpdate
    public void preUpdate() {
        if(!password.equals(passwordTransient)){
            encodePassword();
        }
    }
       protected void encodePassword() {
        password = ((PasswordEncoder)SpringUtils.getBean("passwordEncoder")).encode(password);
    }
}