package com.bmzymtr.business.entity.core;

import jakarta.persistence.*;
import org.hibernate.annotations.Comment;
import org.springframework.data.annotation.CreatedDate;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.sql.Timestamp;


@Comment("系统登录记录表")
@Table(name = "system_login_record")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class SystemLoginRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private Long id;
    @Comment("登录用户")
    @ManyToOne
    @JoinColumn(name = "base_user_id")
    private BaseUser baseUser;
    @Comment("创建时间-登录时间")
    @CreatedDate
    @Column(name = "created_date",nullable = false)
    private Timestamp createdDate;

    @Comment("远程地址")
    @Column(name = "remoteaddr", length = 200)
    private String remoteaddr;
    @Comment("用户token")
    @Column(name = "token", length = 200)
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getRemoteaddr() {
        return remoteaddr;
    }

    public void setRemoteaddr(String remoteaddr) {
        this.remoteaddr = remoteaddr;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public BaseUser getBaseUser() {
        return baseUser;
    }

    public void setBaseUser(BaseUser baseUser) {
        this.baseUser = baseUser;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}