package com.bmzymtr.business.entity.core;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.GenericGenerator;

@Comment("系统租户表")
@Table(name = "tenant")
@Entity
@GenericGenerator(name="jpa-uuid",strategy = "uuid") //uuid,guid,hilo,assigned,identity,select,sequence,seqhilo,increment,foreign,uuid.hex,sequence-identity
public class Tenant implements org.camunda.bpm.engine.identity.Tenant {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(generator = "jpa-uuid")
    private String id;
    @Version
    @Column(name = "version")
    private int version;
    @NotNull(message = "租户名称不允许为空")
    @Comment("租户名称")
    @Column(name = "name", length = 100, nullable = false, unique = true)
    private String name;
    @Comment("租户描述")
    @Column(name = "description")
    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    public int getVersion() {
        return version;
    }
    public void setVersion(int version) {
        this.version = version;
    }
}