package com.bmzymtr.business.entity.core;

import jakarta.persistence.*;
import org.hibernate.annotations.Comment;

@Comment("用户角色映射表")
@Table(name = "base_user_base_role")
@Entity
@IdClass(BaseUserBaseRoleId.class)
public class BaseUserBaseRole {
    @Comment("系统角色")
    @Id
    @ManyToOne
    @JoinColumn(name = "base_role_id")
    private BaseRole baseRole;
    @Comment("系统用户")
    @Id
    @ManyToOne
    @JoinColumn(name = "base_user_id")
    private BaseUser baseUser;

    public BaseUserBaseRole(){

    }
    public BaseUserBaseRole(BaseUser baseUser,BaseRole baseRole) {
        this.baseRole = baseRole;
        this.baseUser = baseUser;
    }

    public BaseUser getBaseUser() {
        return baseUser;
    }

    public void setBaseUser(BaseUser baseUser) {
        this.baseUser = baseUser;
    }

    public BaseRole getBaseRole() {
        return baseRole;
    }

    public void setBaseRole(BaseRole baseRole) {
        this.baseRole = baseRole;
    }
}