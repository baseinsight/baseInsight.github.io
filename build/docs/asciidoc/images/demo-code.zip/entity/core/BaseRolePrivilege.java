package com.bmzymtr.business.entity.core;

import jakarta.persistence.*;
import org.hibernate.annotations.Comment;

@Comment("角色权限映射表")
@Table(name = "base_role_privilege")
@Entity
@IdClass(BaseRolePrivilegeId.class)
public class BaseRolePrivilege {
    @Comment("系统角色")
    @Id
    @ManyToOne
    @JoinColumn(name = "base_role_id")
    private BaseRole baseRole;
    @Comment("系统权限")
    @Id
    @ManyToOne
    @JoinColumn(name = "privilege_id")
    private Privilege privilege;

    public BaseRolePrivilege(){

    }
    public BaseRolePrivilege(BaseRole baseRole,Privilege privilege) {
        this.baseRole = baseRole;
        this.privilege = privilege;
    }

    public BaseRole getBaseRole() {
        return baseRole;
    }

    public void setBaseRole(BaseRole baseRole) {
        this.baseRole = baseRole;
    }

    public Privilege getPrivilege() {
        return privilege;
    }

    public void setPrivilege(Privilege privilege) {
        this.privilege = privilege;
    }
}
