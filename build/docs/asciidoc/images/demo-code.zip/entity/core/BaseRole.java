package com.bmzymtr.business.entity.core;



import com.bmzymtr.business.entity.core.Embedded.AuditingData;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;

import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.Comment;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;


/**
 * 系统基本角色类
 */
@Comment("系统角色表")
@DynamicUpdate
@Table(name = "base_role")
@Entity
@EntityListeners(AuditingEntityListener.class)
public class BaseRole  implements org.camunda.bpm.engine.identity.Group{

    @Id
    @Column(name = "id", nullable = false)
    private String id;
    @Version
    @Column(name = "version")
    private int version;
    @NotNull(message = "角色标识不允许为空")
    @Comment("角色标识")
    @Column(name = "authority", length = 100, nullable = false, unique = true)
    private String authority;
    @Comment("角色名称")
    @Column(name = "name", length = 100)
    private String name;
    @Comment("角色类型")
    @Column(name = "type", length = 100)
    private String type;
    @Embedded
    private AuditingData auditingData = new AuditingData();

    public AuditingData getAuditingData() {
        return auditingData;
    }

    public void setAuditingData(AuditingData auditingData) {
        this.auditingData = auditingData;
    }

    public int getVersion() {
        return version;
    }
    public void setVersion(int version) {
        this.version = version;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return authority;
    }


}