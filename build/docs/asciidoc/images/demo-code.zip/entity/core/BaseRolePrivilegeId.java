package com.bmzymtr.business.entity.core;

import java.io.Serializable;

public class BaseRolePrivilegeId implements Serializable {
    private BaseRole baseRole;
    private Privilege privilege;
}
