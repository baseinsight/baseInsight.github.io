package com.bmzymtr.business.entity.core;


import java.io.Serializable;

public class BaseUserBaseRoleId implements Serializable {
    private BaseRole baseRole;
    private BaseUser baseUser;
}
