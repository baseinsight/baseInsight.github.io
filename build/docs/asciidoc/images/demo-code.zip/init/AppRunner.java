package com.bmzymtr.business.init;

import com.bmzymtr.business.entity.core.*;
import com.bmzymtr.business.repository.core.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import info.baseinsight.core.SpringUtils;
import info.baseinsight.plugin.springsecurity.tool.SpringSecurityUtils;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Transactional
@Component
public class AppRunner implements ApplicationRunner {
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    BaseRoleRepository baseRoleRepository;
    @Autowired
    BaseUserRepository baseUserRepository;
    @Autowired
    BaseUserBaseRoleRepository baseUserBaseRoleRepository;
    @Autowired
    RequestmapRepository requestmapRepository;
    @Autowired
    TenantRepository tenantRepository;
    @Autowired PrivilegeRepository privilegeRepository;
    @Autowired BaseRolePrivilegeRepository baseRolePrivilegeRepository;

    @Override
    public void run(ApplicationArguments args) throws Exception {
            //应用初始化
        //模块数据初始化
        createDefaultTenant();
        createDefaultRoles();
        createDefaultPrivileges();
        createDefaultUsers();
        createRequestMap();
        //----

    }
    private void createDefaultPrivileges(){
        if(privilegeRepository.count()==0){
            BaseRole adminRole=baseRoleRepository.findByAuthority("ROLE_ADMIN");
            Privilege privilege=new Privilege();
            privilege.setName("system:menu:add");  //baseUser:index:addButton
            privilege.setDescription("系统菜单增加权限");
            privilegeRepository.saveAndFlush(privilege);
            BaseRole userRole=baseRoleRepository.findByAuthority("ROLE_USER");
            baseRolePrivilegeRepository.saveAndFlush(new BaseRolePrivilege(userRole,privilege));
        }
    }
    private void createDefaultTenant(){
        if(tenantRepository.findByName("总公司")==null){
            Tenant tenant = new Tenant();
            tenant.setName("总公司");
            tenant.setDescription("总公司租户");
            tenantRepository.saveAndFlush(tenant);
        }
        if(tenantRepository.findByName("分公司1")==null){
            Tenant tenant = new Tenant();
            tenant.setName("分公司1");
            tenant.setDescription("分公司1租户");
            tenantRepository.saveAndFlush(tenant);
        }
        if(tenantRepository.findByName("分公司2")==null){
            Tenant tenant = new Tenant();
            tenant.setName("分公司2");
            tenant.setDescription("分公司2租户");
            tenantRepository.saveAndFlush(tenant);
        }
        if(tenantRepository.findByName("分公司3")==null){
            Tenant tenant = new Tenant();
            tenant.setName("分公司3");
            tenant.setDescription("分公司3租户");
            tenantRepository.saveAndFlush(tenant);
        }
        if(tenantRepository.findByName("分公司4")==null){
            Tenant tenant = new Tenant();
            tenant.setName("分公司4");
            tenant.setDescription("分公司4租户");
            tenantRepository.saveAndFlush(tenant);
        }
    }
    private void createDefaultRoles(){
        if(baseRoleRepository.findByAuthority("ROLE_ADMIN")==null){
            BaseRole baseRole = new BaseRole();
            baseRole.setId("ROLE_ADMIN");
            baseRole.setAuthority("ROLE_ADMIN");
            baseRole.setName("ROLE_ADMIN");
            baseRole.setType("管理员");
            baseRoleRepository.saveAndFlush(baseRole);
        }
        if(baseRoleRepository.findByAuthority("ROLE_USER")==null){
            BaseRole baseRole = new BaseRole();
            baseRole.setId("ROLE_USER");
            baseRole.setAuthority("ROLE_USER");
            baseRole.setName("ROLE_USER");
            baseRole.setType("基本用户");
            baseRoleRepository.saveAndFlush(baseRole);
        }
        if(baseRoleRepository.findByAuthority("ROLE_GUEST")==null){
            BaseRole baseRole = new BaseRole();
            baseRole.setId("ROLE_GUEST");
            baseRole.setAuthority("ROLE_GUEST");
            baseRole.setName("ROLE_GUEST");
            baseRole.setType("访客用户");
            baseRoleRepository.saveAndFlush(baseRole);
        }

        SpringSecurityUtils.resetRoleHierarchy("""
                ROLE_ADMIN > ROLE_USER
                ROLE_USER > ROLE_GUEST
                """);
    }
    private void createDefaultUsers(){
        Tenant tenant=tenantRepository.findByName("总公司");
        BaseRole adminRole=baseRoleRepository.findByAuthority("ROLE_ADMIN");
        BaseRole userRole=baseRoleRepository.findByAuthority("ROLE_USER");
        BaseUser baseUser=baseUserRepository.findByUsername("admin");
        if(baseUser==null){
            baseUser=new BaseUser();
            baseUser.setUsername("admin");
            baseUser.setFirstName("admin");
            baseUser.setLastName("manager");
            baseUser.setEmail("admin@bmzymtr.com");
            baseUser.setPassword("admin");
            baseUser.setTenant(tenant);
            baseUser.setEnabled(true);
            baseUserRepository.saveAndFlush(baseUser);
            baseUserBaseRoleRepository.saveAndFlush(new BaseUserBaseRole(baseUser,adminRole));
        }
        baseUser=baseUserRepository.findByUsername("user");
        if(baseUser==null){
            baseUser=new BaseUser();
            baseUser.setUsername("user");
            baseUser.setFirstName("user");
            baseUser.setLastName("employee");
            baseUser.setEmail("user@bmzymtr.com");
            baseUser.setPassword("user");
            baseUser.setTenant(tenant);
            baseUser.setEnabled(true);
            baseUserRepository.saveAndFlush(baseUser);
            baseUserBaseRoleRepository.saveAndFlush(new BaseUserBaseRole(baseUser,userRole));
        }
    }
    private void createRequestMap() throws JsonProcessingException {
        if(requestmapRepository.count()==0L){
            String str= """
                       [
                        {"name":"favicon.ico resource","url":"/favicon.ico","configAttribute":"permitAll"},
                        {"name":"自定义错误","url":"/error/**","configAttribute":"permitAll"},
                        {"name":"登录控制","url":"/login/**","configAttribute":"isAnonymous()"},
                        {"name":"登出控制","url":"/logout/**","configAttribute":"permitAll"},
                        {"name":"数据库控制台","url":"/dbconsole/**","configAttribute":"hasAnyRole('ROLE_ADMIN')"},
                        {"name":"用户管理","url":"/baseUser/**","configAttribute":"hasAnyRole('ROLE_ADMIN')"},
                        {"name":"角色管理","url":"/baseRole/**","configAttribute":"hasAnyRole('ROLE_ADMIN')"},
                        {"name":"用户角色映射管理","url":"/baseUserBaseRole/**","configAttribute":"hasAnyRole('ROLE_ADMIN')"},
                        {"name":"访问控制管理","url":"/requestmap/**","configAttribute":"hasAnyRole('ROLE_ADMIN')"},
                        {"name":"系统登录日志","url":"/systemLoginRecord/**","configAttribute":"hasAnyRole('ROLE_ADMIN')"},
                        {"name":"系统首页","url":"/","configAttribute":"permitAll"},
                        {"name":"/**管理","url":"/**","configAttribute":"isFullyAuthenticated()"}
                       ] 
                        """;
            List<Map<String,String>> list=objectMapper.readValue(str,List.class);
            list.forEach(item-> {
                Requestmap requestmap=new Requestmap();
                requestmap.setName(item.get("name"));
                requestmap.setUrl(item.get("url"));
                requestmap.setConfigAttribute(item.get("configAttribute"));
                requestmapRepository.saveAndFlush(requestmap);
            });
        }
    }
}
