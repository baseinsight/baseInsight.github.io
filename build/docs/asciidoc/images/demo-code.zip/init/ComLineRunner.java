package com.bmzymtr.business.init;



import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;



@Transactional
@Component
public class ComLineRunner implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
       //

        System.out.println("CommandLineRunner");
    }
}