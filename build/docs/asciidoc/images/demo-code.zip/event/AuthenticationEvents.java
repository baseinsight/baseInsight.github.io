package com.bmzymtr.business.event;

import info.baseinsight.plugin.springsecurity.rest.token.AccessToken;
import org.springframework.context.event.EventListener;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Component;

@Component
public class AuthenticationEvents {
    @EventListener
    public void onSuccess(AuthenticationSuccessEvent success) {
        // ...
        Object source=success.getSource();
        if(source instanceof UsernamePasswordAuthenticationToken){
            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken=(UsernamePasswordAuthenticationToken)source;
            User user=(User) usernamePasswordAuthenticationToken.getPrincipal();
            user.getUsername();
            WebAuthenticationDetails webAuthenticationDetails= (WebAuthenticationDetails)usernamePasswordAuthenticationToken.getDetails();
            if(webAuthenticationDetails!=null){
                webAuthenticationDetails.getRemoteAddress();
                webAuthenticationDetails.getSessionId();
            }
        }
        if(source instanceof AccessToken){
            AccessToken accessToken=(AccessToken)source;
            User user=(User) accessToken.getPrincipal();
            user.getUsername();
        }
        System.out.println(success.toString());
    }

    @EventListener
    public void onFailure(AbstractAuthenticationFailureEvent failures) {
        Object source=failures.getSource();
        if(source instanceof UsernamePasswordAuthenticationToken){
            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken=(UsernamePasswordAuthenticationToken) source;
        }
        if(source instanceof AccessToken){
            AccessToken accessToken=(AccessToken)source;
        }
        Exception exception=failures.getException();
        System.out.println(failures.toString());
    }
}
