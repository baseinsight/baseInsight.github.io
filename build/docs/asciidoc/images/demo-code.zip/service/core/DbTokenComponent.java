package com.bmzymtr.business.service.core;

import com.bmzymtr.business.entity.core.AuthenticationToken;
import com.bmzymtr.business.repository.core.AuthenticationTokenRepository;
import info.baseinsight.plugin.springsecurity.rest.db.DbRestProperties;
import info.baseinsight.plugin.springsecurity.rest.db.storage.DbTokenInterface;
import info.baseinsight.plugin.springsecurity.rest.token.storage.TokenNotFoundException;
import info.baseinsight.plugin.springsecurity.userdetails.CoreUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
// token的db存储的组件实现类，将类库与本地应用的表格结合
@Component
public class DbTokenComponent implements DbTokenInterface {
    @Autowired
    AuthenticationTokenRepository authenticationTokenRepository;
    @Override
    public Object findExistingToken(String tokenValue, UserDetailsService userDetailsService) {
       return authenticationTokenRepository.findByTokenValue(tokenValue);
    }

    @Override
    public void removeToken(String tokenValue) throws TokenNotFoundException {
        authenticationTokenRepository.deleteByTokenValue(tokenValue);
    }

    @Override
    public void storeToken(String tokenValue, UserDetails principal) {
        AuthenticationToken authenticationToken=new AuthenticationToken();
        authenticationToken.setTokenValue(tokenValue);
        authenticationToken.setUsername(principal.getUsername());
        authenticationTokenRepository.saveAndFlush(authenticationToken);
    }

    @Override
    public UserDetails loadUserByToken(String tokenValue, DbRestProperties dbRestProperties, UserDetailsService userDetailsService) throws TokenNotFoundException {
        AuthenticationToken existingToken = (AuthenticationToken)this.findExistingToken(tokenValue,userDetailsService);

        if (existingToken!=null) {
            if(dbRestProperties.getDb().isAutoAccessCount()){
                existingToken.setAccessCount(existingToken.getAccessCount()+1);
                authenticationTokenRepository.saveAndFlush(existingToken);
            }
            String username = existingToken.getUsername();
            return userDetailsService.loadUserByUsername(username);
        }else{
            throw new TokenNotFoundException("Token ${tokenValue} not found");
        }
    }
}
