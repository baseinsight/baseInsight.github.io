package com.bmzymtr.business.service.core;

import com.bmzymtr.business.entity.core.BaseRolePrivilege;
import com.bmzymtr.business.entity.core.BaseUser;
import com.bmzymtr.business.entity.core.BaseUserBaseRole;
import com.bmzymtr.business.repository.core.BaseRolePrivilegeRepository;
import com.bmzymtr.business.repository.core.BaseUserBaseRoleRepository;
import com.bmzymtr.business.repository.core.BaseUserRepository;
import com.bmzymtr.business.repository.core.RequestmapRepository;
import info.baseinsight.plugin.springsecurity.userdetails.CoreSecurityOperater;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

// springsecurity的组件实现类，将安全的的查询类库与本地应用的表格结合
@Component
public class CoreSecurityComponent implements CoreSecurityOperater {
    @Autowired
    RequestmapRepository requestmapRepository;
    @Autowired
    BaseUserRepository baseUserRepository;
    @Autowired
    BaseUserBaseRoleRepository baseUserBaseRoleRepository;
    @Autowired
    BaseRolePrivilegeRepository baseRolePrivilegeRepository;
    @Override
    public Object findUserByUsername(String username) {
        return baseUserRepository.findByUsername(username);
    }

    @Override
    public Object findUserById(Object id) {
        return baseUserRepository.findById((String)id);
    }

    @Override
    public List findAllUserAuthorities(Object user) {
        List<String> roleNameList= new ArrayList<String>();
        List<BaseUserBaseRole> list=baseUserBaseRoleRepository.findAllByBaseUserId(((BaseUser)user).getId());
        list.forEach(baseUserBaseRole->{
            roleNameList.add(baseUserBaseRole.getBaseRole().getAuthority());
        });
        return roleNameList;
    }

    @Override
    public List findAllUserPrivileges(List<String> roleNames) {
        List<String> privilegeNameList= new ArrayList<String>();
        List<BaseRolePrivilege> list=baseRolePrivilegeRepository.findAllByBaseRoleIdIn(roleNames);
        list.forEach(baseRolePrivilege->{
            privilegeNameList.add(baseRolePrivilege.getPrivilege().getName());
        });
        return privilegeNameList;
    }

    @Override
    public List findAllRequestmaps() {
        return requestmapRepository.findAll(Sort.by(Sort.Direction.ASC,"id"));
    }

    @Override
    public List findAllRequestmapsByRoleName(String roleName) {
        return requestmapRepository.findAllByConfigAttributeLike(roleName);
    }
}
