package com.bmzymtr.business.service.core;

import com.bmzymtr.business.entity.core.Tenant;
import com.bmzymtr.business.repository.core.TenantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Transactional
@Service
public class TenantService {
    @Autowired
    TenantRepository tenantRepository;
    public Tenant get(String id) {
        return tenantRepository.findById(id);
    }
    public Map list() {
        Map map = new HashMap();

        return map;
    }

    public Map save(){
        return null;
    }

    public Map update(){
        return null;
    }

    public Map delete(){
        return null;
    }

    public Map deletes(){
        return null;
    }
    public Map download(){
        return null;
    }
}
