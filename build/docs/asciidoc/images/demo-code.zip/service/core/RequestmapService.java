package com.bmzymtr.business.service.core;

import com.bmzymtr.business.repository.core.RequestmapRepository;
import com.bmzymtr.business.repository.core.TenantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class RequestmapService {
    @Autowired RequestmapRepository requestmapRepository;

}
