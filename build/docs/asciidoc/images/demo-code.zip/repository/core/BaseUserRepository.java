package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.BaseRole;
import com.bmzymtr.business.entity.core.BaseUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.UUID;

public interface BaseUserRepository extends JpaRepository<BaseUser, UUID> , JpaSpecificationExecutor<BaseUser> {
    BaseUser findByUsername(String username);
    BaseUser findById(String id);
}