package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.Tenant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface TenantRepository extends JpaRepository<Tenant,  UUID> {
    Tenant findByName(String name);
    Tenant findById(String id);
}