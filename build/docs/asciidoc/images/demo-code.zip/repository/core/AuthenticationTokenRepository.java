package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.AuthenticationToken;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthenticationTokenRepository extends JpaRepository<AuthenticationToken, Long> {
    public AuthenticationToken findByTokenValue(String tokenValue);
    public long deleteByTokenValue(String tokenValue);
}