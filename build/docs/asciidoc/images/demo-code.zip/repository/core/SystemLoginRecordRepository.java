package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.SystemLoginRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SystemLoginRecordRepository extends JpaRepository<SystemLoginRecord, Long> {
}