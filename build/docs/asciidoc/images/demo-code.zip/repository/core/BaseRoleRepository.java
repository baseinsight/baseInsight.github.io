package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.BaseRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface BaseRoleRepository extends JpaRepository<BaseRole, String>, JpaSpecificationExecutor<BaseRole> {
    BaseRole findByAuthority(String authority);
    BaseRole findBaseRoleById(String id);
    long countById(String id);
    long countByIdIn(String[] ids);
}