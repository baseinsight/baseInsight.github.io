package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.BaseRole;
import com.bmzymtr.business.entity.core.BaseRolePrivilege;
import com.bmzymtr.business.entity.core.BaseUserBaseRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BaseRolePrivilegeRepository extends JpaRepository<BaseRolePrivilege, BaseRole> {
    List<BaseRolePrivilege> findAllByBaseRoleId(String baseRoleId);
    List<BaseRolePrivilege> findAllByBaseRoleIdIn(List<String> baseRoleIdList);
}