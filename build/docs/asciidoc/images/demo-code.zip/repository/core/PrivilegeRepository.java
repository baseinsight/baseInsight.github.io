package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.Privilege;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PrivilegeRepository extends JpaRepository<Privilege, Long> {
}