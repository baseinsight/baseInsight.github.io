package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.BaseRole;
import com.bmzymtr.business.entity.core.BaseUser;
import com.bmzymtr.business.entity.core.BaseUserBaseRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BaseUserBaseRoleRepository extends JpaRepository<BaseUserBaseRole, BaseRole> {
    List<BaseUserBaseRole> findAllByBaseUserId(String baseUserId);
    List<BaseUserBaseRole> findAllByBaseRoleId(String baseRoleId);
    List<BaseUserBaseRole> findAllByBaseRoleIdIn(List<String> baseRoleIdList);
}