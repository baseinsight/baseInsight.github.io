package com.bmzymtr.business.repository.core;

import com.bmzymtr.business.entity.core.Requestmap;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RequestmapRepository extends JpaRepository<Requestmap, Long> {
    List<Requestmap> findAllByConfigAttributeLike(String roleName);
}